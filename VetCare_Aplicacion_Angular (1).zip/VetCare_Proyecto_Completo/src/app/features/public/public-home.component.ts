import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'vc-public-home',
  template: `
    <header class="public-nav">
      <a class="public-brand" routerLink="/" aria-label="VetCare inicio"><img src="assets/images/logo-vetcare.png" alt="VetCare, clínica veterinaria"></a>
      <nav aria-label="Navegación principal">
        <a class="active" routerLink="/">Inicio</a><a routerLink="/" fragment="servicios">Servicios</a><a routerLink="/" fragment="nosotros">Nosotros</a><a routerLink="/" fragment="contacto">Contacto</a>
      </nav>
      <div class="public-actions" *ngIf="!auth.isAuthenticated(); else signedIn"><a routerLink="/acceso">Iniciar sesión</a><a class="register-link" [routerLink]="['/acceso']" [queryParams]="{mode:'register'}">Registrarse</a></div>
      <ng-template #signedIn><a class="register-link" routerLink="/app">Ir a mi panel</a></ng-template>
    </header>
    <main>
      <section class="public-hero">
        <div class="hero-copy"><span class="hero-kicker">CUIDADO CERCANO PARA CADA MASCOTA</span><h1>Cuidado experto para cada etapa de su vida</h1><p>Atención veterinaria integral, cercana y confiable para tu mascota.</p><div class="hero-actions"><button class="hero-primary" (click)="reserve()"><span>▦</span> Reservar una cita</button><a class="hero-secondary" href="#servicios">Conocer servicios <span>›</span></a></div></div>
        <img class="hero-photo" src="assets/images/clinica-vetcare.png" alt="Veterinaria atendiendo a un perro con su familia y un gato">
      </section>
      <section class="trust-strip" id="nosotros"><div><span class="trust-icon">♧</span><strong>Atención personalizada</strong></div><div><span class="trust-icon">✹</span><strong>Profesionales calificados</strong></div><div><span class="trust-icon">▦</span><strong>Citas organizadas</strong></div></section>
      <section class="public-services" id="servicios"><div class="section-title"><span>VETCARE · SERVICIOS</span><h2>Nuestros servicios</h2><i></i></div>
        <div class="service-cards"><a class="service-card" *ngFor="let item of services" [routerLink]="['/servicios', item.slug]"><span class="service-icon" [class.green-icon]="item.tone === 'green'">{{ item.icon }}</span><div><h3>{{ item.title }}</h3><p>{{ item.description }}</p></div><span class="card-arrow">›</span></a></div>
      </section>
      <section class="signup-banner"><span class="info-mark">i</span><div><strong>¿Primera vez en VetCare?</strong><span> Registra tu cuenta para agendar y llevar el historial de tu mascota.</span></div><a [routerLink]="['/acceso']" [queryParams]="{mode:'register'}">Registrarse</a></section>
    </main>
    <footer id="contacto" class="public-footer"><span>VetCare · Cuidado veterinario cercano</span><a [routerLink]="['/acceso']" [queryParams]="{returnUrl:'/app/citas'}">Reservar una cita</a></footer>
  `
})
export class PublicHomeComponent {
  readonly services = [
    { slug: 'consulta-general', title: 'Consulta general', description: 'Evaluación integral para mantener su salud y bienestar.', icon: '✚', tone: 'green' },
    { slug: 'vacunacion', title: 'Vacunación', description: 'Esquemas de vacunación seguros y actualizados.', icon: '⚕', tone: 'blue' },
    { slug: 'desparasitacion', title: 'Desparasitación', description: 'Prevención y control de parásitos internos y externos.', icon: '⟲', tone: 'green' },
    { slug: 'bano-cuidado', title: 'Baño y cuidado', description: 'Higiene y cuidado especializado para su bienestar.', icon: '♧', tone: 'blue' }
  ];
  constructor(readonly auth: AuthService, private readonly router: Router) {}
  reserve(): void {
    if (this.auth.isAuthenticated()) void this.router.navigate(['/app/citas']);
    else void this.router.navigate(['/acceso'], { queryParams: { returnUrl: '/app/citas' } });
  }
}
